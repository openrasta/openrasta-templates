﻿namespace OpenRasta.AspNetTemplate.Resources
{
    public class Home
    {
    }
}
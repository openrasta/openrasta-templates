﻿using System;

namespace OpenRasta.AspNetTemplate.Resources
{
    public class Home
    {
        public string Message { get; set; }
    }
}